##############################################################################
# Script Name: chs_pb_get_ouput_from_all_agents.sh 
# Description: Get ouput from all agents
##############################################################################

echo "Get chs4linux output files from LM agents"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_get_output_files.yaml -i /etc/ansible/chs4linux/inventory/agents_lm

echo "Get chs4linux output files from EF agents"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_get_output_files.yaml -i /etc/ansible/chs4linux/inventory/agents_ef

echo "Get chs4linux output files from RBK agents"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_get_output_files.yaml -i /etc/ansible/chs4linux/inventory/agents_rbk

