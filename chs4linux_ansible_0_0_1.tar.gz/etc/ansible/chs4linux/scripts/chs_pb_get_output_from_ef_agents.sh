##############################################################################
# Script Name: chs_pb_get_output_from_ef_agents.sh
# Description: Get ouput from EF agents
##############################################################################

echo "Get chs4linux output files from EF agents"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_get_output_files.yaml -i /etc/ansible/chs4linux/inventory/agents_ef


