##############################################################################
# Script Name: chs_pb_get_output_from_lm_agents.sh
# Description: Get ouput from LM agents
##############################################################################

echo "Get chs4linux output files from LM agents"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_get_output_files.yaml -i /etc/ansible/chs4linux/inventory/agents_lm

