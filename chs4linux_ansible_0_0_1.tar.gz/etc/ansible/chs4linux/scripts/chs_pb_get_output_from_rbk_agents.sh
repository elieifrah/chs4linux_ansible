##############################################################################
# Script Name: chs_pb_get_output_from_rbk_agents.sh
# Description: Get ouput from RBK agents
##############################################################################

echo "Get chs4linux output files from RBK agents"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_get_output_files.yaml -i /etc/ansible/chs4linux/inventory/agents_rbk


