##############################################################################
# Script Name: chs_pb_run_policy_on_all_agents.sh
# Description: Run policy on all agents
##############################################################################

echo "Run policy on LM agents"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_run_policy.yaml -i /etc/ansible/chs4linux/inventory/agents_lm

echo "Run policy on EF agents"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_run_policy.yaml -i /etc/ansible/chs4linux/inventory/agents_ef

echo "Run policy on RBK agents"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_run_policy.yaml -i /etc/ansible/chs4linux/inventory/agents_rbk


