##############################################################################
# Script Name: chs_pb_run_policy_on_ef_agents.sh
# Description: Run policy on EF agents
##############################################################################

echo "Run policy on EF agents"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_run_policy.yaml -i /etc/ansible/chs4linux/inventory/agents_ef


