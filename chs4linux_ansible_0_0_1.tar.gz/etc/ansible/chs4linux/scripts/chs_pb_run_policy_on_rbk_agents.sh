##############################################################################
# Script Name: chs_pb_run_policy_on_rbk_agents.sh
# Description: Run policy on RBK agents
##############################################################################

echo "Run policy on RBK agents"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_run_policy.yaml -i /etc/ansible/chs4linux/inventory/agents_rbk


