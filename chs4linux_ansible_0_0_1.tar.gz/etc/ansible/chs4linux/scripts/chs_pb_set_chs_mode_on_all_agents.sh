##############################################################################
# Script Name: chs_pb_set_chs_mode_on_all_agents.sh
# Description: Set agents to their respective chs_mode (LM/EF/RBK)
##############################################################################

echo "Set LM agents chs_mode to LM"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_set_to_lm.yaml -i /etc/ansible/chs4linux/inventory/agents_lm

echo "Set EF agents chs_mode to EF"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_set_to_ef.yaml -i /etc/ansible/chs4linux/inventory/agents_ef

echo "Set RBK agents chs_mode to RBK"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_set_to_rbk.yaml -i /etc/ansible/chs4linux/inventory/agents_rbk


