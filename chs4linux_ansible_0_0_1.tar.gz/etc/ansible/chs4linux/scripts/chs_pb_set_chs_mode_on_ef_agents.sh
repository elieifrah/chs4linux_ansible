##############################################################################
# Script Name: chs_pb_set_to_ef.sh
# Description: Set EF agents chs_mode to EF
##############################################################################

echo "Set EF agents chs_mode to EF"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_set_to_ef.yaml -i /etc/ansible/chs4linux/inventory/agents_ef


