##############################################################################
# Script Name: chs_pb_set_to_lm.sh
# Description: Set CHS Mode to LM
##############################################################################

echo "Set LM agents chs_mode to LM"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_set_to_lm.yaml -i /etc/ansible/chs4linux/inventory/agents_lm


