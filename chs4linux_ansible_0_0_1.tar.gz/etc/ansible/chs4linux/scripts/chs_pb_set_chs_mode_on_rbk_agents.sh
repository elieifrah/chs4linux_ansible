##############################################################################
# Script Name: chs_pb_set_to_rbk.sh
# Description: Set RBK agents chs_mode to RBK
##############################################################################

echo "Set RBK agents chs_mode to RBK"
ansible-playbook /etc/ansible/chs4linux/playbooks/chs_pb_set_to_rbk.yaml -i /etc/ansible/chs4linux/inventory/agents_rbk


